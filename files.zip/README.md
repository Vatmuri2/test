# Pong Game in GitHub Codespace

## How to Play

1. **Start the web server**  
   In your Codespace terminal, run: